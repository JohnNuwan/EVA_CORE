---
name: rl-trading-debugging
description: >-
  Diagnostic et correction des échecs d'entraînement RL pour le trading —
  patterns de collapse du reward, choix d'algorithme (ES vs PPO vs Dreamer),
  tests synthétiques de capacité, et pièges spécifiques aux environnements
  financiers.
category: mlops
---

# Diagnostic RL pour Trading

## Présentation

Ce skill documente les patterns d'échec récurrents dans l'entraînement
d'agents RL pour le trading (FTMO challenges, forex, crypto) et les
solutions validées expérimentalement. Couvre DreamerV3, PPO, et Evolution
Strategies (ES).

## Pattern #1 : Collapse du reward head vers la moyenne

**Symptôme** : `reward_loss = 0.0000` dans les logs, `entropy` stagne à ~1.38 nat,
l'agent fait 0 trades en validation.

**Cause racine** : Le reward_head (MLP 2×512) du World Model DreamerV3 prédit
la moyenne des rewards pour tous les états. Le MSE (Mean Squared Error) a
pour solution optimale la moyenne de la distribution. Avec ~90% de steps
HOLD (reward ~0) et ~10% de trades (reward ~+0.20), le réseau sort ~0.04
pour tout.

**Tentatives échouées** :
- Weighted MSE (pondération par écart à la moyenne) : ne suffit pas
- Stratified sampling 50/50 HOLD/trades : le réseau converge quand même
- Prior+posterior reward loss : inutile si KL=0
- Warm-up RSSM 80 épisodes : le RSSM ignore les observations (KL≈0)
- KL weight ×20 (0.1→2.0) : ne force pas le RSSM à utiliser les observations
- Reward_head 3×2048 sur GPU1 séparé : converge toujours vers la moyenne
- Action comme input explicite du reward_head (BUY-HOLD = +0.063 symlog) :
  le signal existe mais l'avantage est noyé dans le bruit

**Conclusion** : DreamerV3 ne convient pas au trading. Le RSSM prior ne
capture pas assez d'info observationnelle (KL→0) parce que les prix sont
des marches aléatoires.

## Pattern #2 : PPO collapse vers entropie zéro

**Symptôme** : `entropy → 0.000` en ~10 itérations, `actor_loss = 0.0`,
validation 0 trades.

**Cause** : Le critic apprend à prédire la valeur constante (toutes les
actions ont la même espérance) → avantages = 0 → pas de gradient pour
l'actor. L'entropie s'effondre vers une politique déterministe HOLD.

**Ne pas utiliser PPO pour le trading** sans avoir d'abord validé que
l'environnement produit des avantages non-nuls.

## Pattern #3 : Credit assignment temporel

**Symptôme** : Même sur un marché synthétique qui monte à 100%, l'agent
ne fait pas BUY.

**Cause** : Pour gagner, l'agent doit exécuter BUY → HOLD... → CLOSE.
La probabilité d'exécuter cette chaîne aléatoirement est infime (~0.5%).
Le reward n'arrive qu'au CLOSE, bien après le BUY.

**Solutions validées** :
1. **Reward dense par step** : donner le delta de PnL non-réalisé à
   chaque step (pas seulement au CLOSE). L'agent voit immédiatement
   l'effet de BUY dans un marché qui monte.
2. **Auto-close** : forcer la fermeture des positions après N bars
   de profit (ex: 20 bars). L'agent n'a pas besoin d'apprendre CLOSE.
3. **Features enrichies** : inclure le PnL non-réalisé et la direction
   de la position directement dans l'observation.

## Pattern #4 : ES (Evolution Strategies) — l'approche qui fonctionne

**Pourquoi ES marche quand DreamerV3 et PPO échouent** :
- Pas de value function → pas de collapse du critic
- Pas de reward_head → pas de prédiction de moyenne
- Optimisation directe du fitness (PnL réalisé)
- Population diversifiée naturellement → exploration inhérente
- Gradient estimé par perturbations (pas de backprop through time)

### Architecture V5.1 recommandée (corrigée, SUPERSEDED by V6 pour multi-symbole)

```
ESPolicy: LSTM 2×128 → head 128→8 actions + frozen_action_mask
...
```

**⚠️ V5.1 est adéquat pour UN SEUL symbole. Pour le multi-symbole,
utiliser l'architecture V6 (Pattern #13) : un agent par symbole.**

### Architecture V6 recommandée (multi-agent spécialisé)
Population: 16 agents parallèles (2 GPUs)
σ (mutation): 0.02
lr (ES): 0.1
elite_frac: 0.25 (top 25% sélectionnés)
Évaluation: 1000 steps, stochastique (temperature 1.5→0.3)
Fitness: PnL RÉALISÉ pur (balance finale - initiale) en %
Bias fixe: HOLD=-4.0, BUY=+3.0, SELL=+3.0, SPLIT=+1.5, CLOSE=+0.5
frozen_action_mask: SEUL HOLD gelé (bias-driven anti-collapse)
                    BUY et SELL DÉGELÉS → LSTM apprend la direction
Evolve: magnitude-based (fit/max_abs_fit, pas sign)
max_workers: len(devices) * 2 (pas *3 — surcharge mémoire)
NaN guard: old_master_vec.clone() avant update, rollback si NaN
empty_cache: torch.cuda.empty_cache() après chaque evaluate + chaque gen
~100s/gen avec pop=16, eval=1000 steps sur 2× RTX 3090 (~5h pour 200 gens)
```

Référence complète : voir `references/code-patterns.md`.
Architecture V6 multi-agent : voir `references/v6-multi-agent.md`.

**PITFALL CRITIQUE** : Ne PAS utiliser le reward total comme fitness.
Les bonus d'ouverture (+0.20/trade) et le time-decay dominent le signal.
Une politique qui trade au hasard peut avoir un reward total > une politique
qui trade peu mais bien. Utiliser le PnL réalisé pur :
```python
fitness = (env.balance - INITIAL_BALANCE) / INITIAL_BALANCE * 100.0
if num_trades > 0:
    fitness += 2.0  # léger bonus d'activité
if num_trades == 0:
    fitness -= 50.0  # pénalité zéro-trade
```

**Antithetic sampling** : évaluer `master + ε` et `master - ε` pour chaque
vecteur de bruit. Le gradient effectif = (fitness_plus - fitness_minus) × ε.
Cela annule le bruit de baseline et double la précision du gradient.

### Configuration environnement

- Rewards denses : 100% des steps non-nuls (pour le WM, pas pour le fitness ES)
- Auto-close : après 20 bars de profit (l'agent n'a pas besoin d'apprendre CLOSE)
- Curriculum learning 3 phases : phase 1 sans frictions → phase 3 réaliste
- PnL scale ×100 en phase 1 (amplifie le signal PnL pour l'ES)

## Pattern #5 : Master ES ne trade pas (logits plats)

**Symptôme** : t±=N/N (toutes les politiques bruitées tradent) mais la
validation déterministe du master fait 0 trades, génération après génération.

**Cause racine** : Les poids du réseau sont initialisés aléatoirement →
tous les logits sont proches de zéro → HOLD est le max par une marge
infime. Les perturbations (σ=0.02) inversent aléatoirement l'argmax,
donc les politiques bruitées tradent. Mais le gradient est du bruit :
les directions de bruit qui font trader ne sont pas corrélées avec
le PnL, donc le master ne converge pas vers le trading.

### Solution initiale (insuffisante seule) : `action_bias` en buffer
Exclu des `parameters()` → non affecté par `_get_params_flat` /
`_set_params_flat` → survit à toutes les mises à jour ES.

```python
class ESPolicy(nn.Module):
    def __init__(self, ...):
        super().__init__()
        self.lstm = nn.LSTM(...)
        self.head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.GELU(),
            nn.Linear(hidden_dim, action_dim, bias=False)  # PAS de bias natif
        )
        # Bias fixe anti-HOLD — buffer non-apprenable
        action_bias = torch.zeros(action_dim)
        action_bias[0] = -2.0    # HOLD  ← pénalisé
        action_bias[1] = +1.0    # BUY   ← favorisé
        action_bias[2] = +1.0    # SELL  ← favorisé
        action_bias[4] = +0.5    # SPLIT_BUY
        action_bias[5] = +0.5    # SPLIT_SELL
        self.register_buffer('action_bias', action_bias)

    def forward(self, x, hidden=None):
        out, h = self.lstm(x, hidden)
        logits = self.head(out[:, -1, :])
        return logits + self.action_bias, h  # biais ajouté ici
```

**Pourquoi `bias=False` sur la dernière couche Linear** : pour éviter un
double biais (le biais natif de Linear + le buffer). Les deux seraient
dans des chemins différents (un dans parameters(), l'autre dans buffers()).

**Piège** : ne PAS utiliser `self.head[-1].bias.data.copy_(bias)` car
le biais de la couche Linear fait partie de `parameters()` et sera
écrasé à chaque `_set_params_flat`.

### Check-list étendue

Quand le master ES ne trade pas en validation :

1. [ ] Vérifier que t± montre que les politiques bruitées tradent
2. [ ] Si t±=N/N mais validation=0 trades → logits plats → Pattern #5
3. [ ] Ajouter un `action_bias` en `register_buffer` avec HOLD négatif
4. [ ] Vérifier que `_get_params_flat` n'inclut PAS le buffer (count_params)
5. [ ] Vérifier que le biais survit après `evolve()` → `_create_population()`

### Dual GPU pour ES

Avec 2 GPUs, paralléliser l'évaluation de la population avec
`ThreadPoolExecutor`. Chaque worker est assigné à un GPU via `device_idx`.

```python
devices = ('cuda:0', 'cuda:1')
# Répartir la population : pop[i] → devices[i % 2]
# max_workers = len(devices) * 3
# Chaque _evaluate_one prend (policy, env, steps, device_idx)
```

PyTorch libère le GIL pendant les opérations CUDA → les threads
sont efficaces pour paralléliser les forward passes LSTM.

## Test Synthétique de Capacité

Avant de debugger un algorithme RL sur données réelles, **toujours tester
sur un environnement synthétique trivial** :

1. Créer un marché qui monte (ou descend) de façon déterministe
2. Donner des rewards denses (delta PnL par step) + auto-close
3. Inclure PnL non-réalisé et direction dans l'observation
4. Vérifier que l'agent apprend BUY (marché haussier) ou SELL (baissier)
   en < 30 générations

Si l'agent n'apprend PAS sur le synthétique, le RL est cassé.
S'il apprend sur le synthétique mais pas sur le réel, le problème
vient des features (pas assez prédictives).

## Pattern #6 : `reset()` écrase les paramètres de validation manuels

**Symptôme** : La validation produit systématiquement 0 trades ou des résultats
incohérents (symboles aléatoires, step aléatoire) alors que l'entraînement
montre des trades (t±=N/N).

**Cause racine** : La méthode `_validate()` définit manuellement des paramètres
spécifiques (`current_symbol`, `current_step`, `start_step`...) pour contrôler
les conditions d'évaluation, puis appelle `env.reset()` qui les écrase avec
des valeurs aléatoires. La validation s'exécute donc sur un environnement
différent de celui prévu.

Ce bug est silencieux : aucun crash, aucun warning. Les métriques de validation
sont simplement fausses (calculées sur des données/symboles aléatoires).

**Exemple de code buggé** :
```python
def _validate(self):
    env = MyEnv(data_dict, curriculum_episode=9999)
    env.current_symbol = 'XAUUSD'
    env.current_step = env.lookback + len(env.df) - 3000  # dernières barres
    env.reset()  # ← ÉCRASE current_symbol et current_step !
    obs = env._get_obs()
```

**Solution** : Ne PAS appeler `reset()` après avoir défini manuellement des
paramètres d'environnement. Initialiser l'état manuellement en répliquant
tous les champs que `reset()` initialise.

```python
def _validate(self):
    env = MyEnv(data_dict, curriculum_episode=9999)
    env.current_symbol = 'XAUUSD'
    env.current_step = env.lookback + len(env.df) - 3000
    # PAS de reset() — init manuelle de TOUS les champs d'état
    env.balance = INITIAL_BALANCE
    env.peak_balance = env.balance
    env.daily_start_balance = env.balance
    env.positions = []
    env.trades_today = 0
    env.total_trades = 0
    env.winning_trades = 0
    env.consecutive_losses = 0
    env.cooldown_until = 0
    env.episode_reward = 0.0
    # ... tous les champs que reset() initialise ...
    obs = env._get_obs()
```

**Piège** : `reset()` dans `__init__` est appelé automatiquement. Si on
override les champs APRÈS la construction mais AVANT d'appeler `reset()`
une deuxième fois, la première initialisation (celle de `__init__`) n'est
pas le problème — c'est bien l'appel explicite à `reset()` APRÈS avoir
défini les paramètres qui est buggé.

**Vérification** : Après l'init manuelle, ajouter une assertion :
```python
assert env.current_symbol == 'XAUUSD'
assert env.current_step == expected_step
```

## Pattern #7 : Antithetic sampling cassé — +ε et -ε sur des marchés différents

**Symptôme** : t±=N/N (toutes les politiques bruitées tradent), fitness effective
faible et non-convergente, validation déterministe = trades mais PnL aléatoire.

**Cause racine** : L'antithetic sampling évalue master+ε et master-ε sur des
environnements DIFFÉRENTS (symboles et steps aléatoires distincts). La
différence de fitness (f_plus - f_minus) est dominée par le bruit du marché,
pas par l'effet de la perturbation ε. Le gradient ES = bruit pur.

**Code buggé** :
```python
for i, ((_, noise, _), _) in enumerate(zip(self.population, envs)):
    # BUG: nouvel env avec reset() aléatoire → marché DIFFÉRENT de envs[i]
    anti_env = MultiSymbolEnvV4(data_dict, ...)
    all_tasks.append((anti_policy, anti_env, ...))
```

**Solution** : Capturer l'état initial de env_plus (symbole, step) AVANT évaluation,
puis l'injecter dans anti_env au lieu d'appeler reset().

```python
# Étape 0 : capturer l'état de chaque env_plus
env_states = [{'symbol': e.current_symbol, 'step': e.current_step,
               'features': e.features, 'df': e.df, 'spec': e.spec}
              for e in envs]

# Antithetic avec MÊME état
for i, ...:
    anti_env = MultiSymbolEnvV4(data_dict, ...)
    all_tasks.append((anti_policy, anti_env, ..., env_states[i]))
```

Et dans `_evaluate_one`, utiliser `init_state` au lieu de `env.reset()`.

**Vérification** : Après le fix, les paires +ε/-ε doivent avoir des fitness
fortement corrélées (même direction de marché). Si fitness_plus ≈ fitness_minus
pour toutes les paires, c'est que le marché domine encore — augmenter pop_size.

## Pattern #8 : Dérive des poids qui contre le bias anti-HOLD → overtrade

**Symptôme V5 (BUY/SELL gelés)** : Le master trade massivement (51 trades en 500 steps de
validation), winrate bloqué à ~41%, PnL négatif systématique. BUY et SELL
ont des logits quasi identiques (~+3.00 chacun) → l'agent alterne BUY/SELL
aléatoirement sans direction.

**Cause racine** : Le `frozen_action_mask` gelait HOLD + BUY + SELL. Avec
BUY=+3.0 et SELL=+3.0 (bias fixe), les deux actions sont toujours également
probables. Le réseau ne peut pas apprendre à choisir la direction car sa
contribution est masquée. L'agent overtrade dans les deux sens et perd
les spreads/commissions.

**Solution V5.1 corrigée** : Geler UNIQUEMENT HOLD. BUY et SELL doivent
être libres pour que le LSTM apprenne à moduler le bias en fonction des
features de marché. Le réseau peut ainsi produire BUY > SELL dans un
marché haussier, et SELL > BUY dans un marché baissier.

```python
class ESPolicy(nn.Module):
    def __init__(self, ...):
        ...
        self.register_buffer('frozen_action_mask', torch.ones(action_dim))
        self.frozen_action_mask[0] = 0.0  # HOLD uniquement → gelé
        # BUY(1) et SELL(2) DÉGELÉS → le réseau apprend la direction

    def forward(self, x, hidden=None):
        out, h = self.lstm(x, hidden)
        logits = self.head(out[:, -1, :])
        return logits * self.frozen_action_mask + self.action_bias, h
```

**Étape obligatoire après evolve()** : remettre à zéro UNIQUEMENT les
poids HOLD (canal 0). Les poids BUY/SELL sont laissés libres.

```python
def evolve(self, fitness):
    ...
    # Seul HOLD (canal 0) est remis à zéro — BUY/SELL libres
    with torch.no_grad():
        self.master.head[-1].weight.data[0] = 0.0
    self._create_population()
```

**Vérification** : Logger `buy_hold_gap = logit[BUY] - logit[HOLD]` ET
`buy_sell_gap = logit[BUY] - logit[SELL]`. Si `buy_sell_gap ≈ 0` après
30+ générations, les features ne sont pas assez informatives pour que
le LSTM apprenne la direction → Pattern #13.

**Piège historique** : La V5 gelait HOLD/BUY/SELL en pensant que « l'agent
n'a pas besoin d'apprendre la direction ». C'est faux : sans modulation
BUY vs SELL par le réseau, l'agent overtrade aléatoirement.

## Pattern #10 : Crash silencieux ES — ThreadPoolExecutor avale les exceptions

**Symptôme** : L'entraînement ES s'arrête brutalement après N générations
sans stack trace, sans message d'erreur. Le processus est simplement mort.
Le log s'arrête net (ex: 13/200 générations).

**Cause racine** : `ThreadPoolExecutor.submit()` exécute `_evaluate_one`
dans des threads. Si une exception est levée dans un worker (OOM CUDA,
IndexError dans l'environnement, NaN dans les tenseurs), elle est capturée
par le Future mais jamais `.result()`-ée si le thread meurt avant. Sans
try/except explicite, le processus s'éteint silencieusement.

**Solution** : Wrapper chaque `future.result()` dans un try/except, et
wrapper tout `evaluate_population()` dans un try/except au niveau de
la boucle d'entraînement.

```python
# Dans evaluate_population() — try/except par future
for future in as_completed(futures):
    anti, idx = futures[future]
    try:
        fitness, num_trades = future.result()
    except Exception as e:
        print(f"   ⚠️  Erreur évaluation (anti={anti}, idx={idx}): {e}")
        fitness = -100.0  # fitness minimale en cas d'erreur
    ...

# Dans train_es.py run() — try/except global
try:
    effective_fitness, fitness_plus, fitness_minus = \
        self.agent.evaluate_population(envs, steps=self.eval_steps)
except Exception as e:
    print(f"   ❌ CRASH gen {gen}: {e}")
    traceback.print_exc()
    self.agent.save(os.path.join(self.save_dir, f'crash_gen{gen}.pt'))
    break
```

**Pourquoi -100 comme fallback** : Une fitness de -100 est pire que la
pénalité zéro-trade (-50). Les élites excluront naturellement ce membre.

## Pattern #11 : NaN dans le gradient ES après plusieurs générations

**Symptôme** : L'entraînement tourne normalement pendant N générations,
puis crash silencieux. Les logs de fitness montrent une dégradation
progressive (best_fitness → 0) avant le crash.

**Cause racine** : Accumulation de NaN dans le gradient ES. Scénario :
- `fit_clipped = np.clip(fit, -100, 100)` où `fit` peut être NaN
  si l'environnement produit un PnL indéfini (division par zéro, etc.)
- `grad += w * noise_primary * (fit_clipped / max_abs_fit)` produit NaN
- `master_vec += self.lr * grad` → master_vec contient NaN
- Le forward suivant (LSTM) produit des NaN → l'évaluation suivante
  produit des NaN → cascade

**Solution** : Sauvegarder `old_master_vec` AVANT l'update, détecter
NaN/Inf après, et rollback si nécessaire.

```python
def evolve(self, fitness):
    ...
    old_master_vec = master_vec.clone()  # sauvegarde AVANT update
    master_vec += self.lr * grad

    if torch.isnan(master_vec).any() or torch.isinf(master_vec).any():
        print(f"   ⚠️  NaN/Inf détecté après evolve! Update annulée.")
        master_vec = old_master_vec  # rollback
    else:
        self._set_params_flat(self.master, master_vec)
    ...
```

**Piège** : Ne PAS faire `master_vec = self._get_params_flat(self.master)`
pour restaurer — si le master a déjà été partiellement modifié, cette
lecture peut retourner des valeurs corrompues. Toujours sauvegarder
avec `.clone()` avant l'update.

## Pattern #12 : Accumulation mémoire GPU entre générations ES

**Symptôme** : Crash OOM après N générations, même avec une petite
population. La mémoire GPU allouée augmente progressivement.

**Cause racine** : Chaque `evaluate_population()` crée N politiques
antithetic (`anti_policy`) sur GPU. PyTorch garde le cache CUDA même
après garbage collection. Les `ThreadPoolExecutor` workers peuvent
aussi accumuler des tenseurs dans leur contexte.

**Solution** :
1. `torch.cuda.empty_cache()` après chaque `evaluate_population()` et
   après chaque génération
2. Réduire `max_workers` de `len(devices)*3` à `len(devices)*2`
3. Nettoyer sur TOUS les GPUs, pas seulement le primary

```python
# Après evaluate_population() — vider le cache sur tous les GPUs
for device in self.devices:
    with torch.cuda.device(device):
        torch.cuda.empty_cache()

# Dans train_es.py run() — après chaque génération
torch.cuda.empty_cache()
```

**Workers ThreadPoolExecutor** : `len(devices) * 2` est suffisant. Avec
`len(devices)*3`, trop de workers se partagent les GPUs, causant des
pics mémoire et des contentions.

**Symptôme** : Le master trade (grâce au frozen_action_mask) mais le PnL
ne s'améliore pas génération après génération. Les best_fitness fluctuent
aléatoirement sans tendance haussière.

**Cause racine** : `np.sign(fit)` donne un poids de ±1 à TOUTES les
perturbations, quelle que soit leur fitness effective. Une perturbation
avec fitness=+0.01 reçoit le même poids qu'une avec fitness=+7.0. Comme
la plupart des fitness effectives sont proches de zéro (bruit de marché),
le gradient est dominé par des signes aléatoires.

**Code buggé** :
```python
for (idx, (fit, (_, noise, device))), w in zip(elite, weights):
    fit_clipped = np.clip(fit, -100, 100)
    grad += w * noise_primary * np.sign(fit_clipped)  # ±1, égalise tout
```

**Solution** : Pondérer par la magnitude normalisée du fitness. Les
perturbations qui donnent un fitness fort reçoivent plus de poids.

```python
# Normaliser par la magnitude max des élites
elite_fitness = np.array([fit for _, (fit, _) in zip(elite, ...)])
max_abs_fit = max(np.max(np.abs(elite_fitness)), 1.0)

for (idx, (fit, (_, noise, device))), w in zip(elite, weights):
    fit_clipped = np.clip(fit, -100, 100)
    grad += w * noise_primary * (fit_clipped / max_abs_fit)  # pondéré
```

**Pourquoi ça aide** : Les perturbations chanceuses (fitness élevé) ont
un impact proportionnellement plus fort sur le gradient. Les perturbations
bruiteuses (fitness ~0) ont un impact négligeable. Le rapport signal/bruit
du gradient s'améliore.

**Piège** : Le `max_abs_fit` doit être calculé sur le même ensemble
d'élites que la boucle de gradient. Ne pas le pré-calculer sur toute
la population (inclut les non-élites).

Quand l'agent ne trade pas :

1. [ ] Vérifier que 100% des steps ont un reward non-nul
2. [ ] Vérifier que BUY/SELL donne un reward immédiat supérieur à HOLD
3. [ ] Tester sur environnement synthétique (trending up/down)
4. [ ] Si ES : vérifier que le fitness (PnL pur) augmente avec les générations
5. [ ] Si ES et t±=N/N mais validation=0 trades → Pattern #5 (logits plats)
6. [ ] Si ES et validation=0 trades mais résultats incohérents → Pattern #6 (reset écrase params)
7. [ ] Logger `buy_hold_gap = logit[BUY] - logit[HOLD]` en validation : si gap < 1.0 → Pattern #8 (poids contrent le bias)
8. [ ] Si PPO/Dreamer : vérifier que l'entropie ne collapse pas à 0
9. [ ] Vérifier que l'observation inclut le statut de position et PnL latent
10. [ ] Ajouter auto-close pour forcer la réalisation du PnL
11. [ ] Vérifier que SEUL HOLD est gelé dans frozen_action_mask, pas BUY/SELL (Pattern #8)
12. [ ] Vérifier que le `head[-1].weight[0]` (HOLD uniquement) est remis à zéro après `evolve()`

Quand l'ES converge vers du trading mais le PnL ne s'améliore pas :

1. [ ] Vérifier que le fitness est basé sur le PnL pur (pas reward total)
2. [ ] Vérifier que l'antithetic sampling utilise le MÊME marché (Pattern #7)
3. [ ] Réduire la température d'exploration (temp_start plus bas)
4. [ ] Augmenter pop_size (16→32) pour un meilleur gradient
5. [ ] Augmenter eval_steps (1000→2000) pour réduire le bruit d'évaluation
6. [ ] Vérifier que le biais anti-HOLD est en buffer ET masqué dans forward (Pattern #8)
7. [ ] Si BUY et SELL ont des logits quasi identiques après 30+ gens → Pattern #8 (features pas assez informatives)
8. [ ] Remplacer `np.sign(fit)` par `fit / max_abs_fit` dans evolve() (Pattern #9)
9. [ ] Logger `buy_hold_gap` ET `buy_sell_gap` en validation
10. [ ] Logger `grad_norm` dans les métriques evolve : si norme → 0, le gradient est mort

Quand le master trade en validation mais PnL négatif systématiquement :

1. [ ] Vérifier que les features sont informatives (corrélation avec rendements futurs)
2. [ ] Tester avec un marché synthétique simple pour valider la capacité d'apprentissage
3. [ ] Ajouter des features de timing (heure de la session, jour de la semaine)
4. [ ] Réduire le nombre d'actions (HOLD/BUY/SELL/CLOSE uniquement)
5. [ ] Si overtrade (>30 trades/500 steps) → vérifier que BUY/SELL ne sont pas tous deux à ~+3.0 (Pattern #8)
6. [ ] Logger `buy_sell_gap = logit[BUY] - logit[SELL]` : si ≈0, le réseau n'apprend pas la direction

Quand l'entraînement crash sans erreur :

1. [ ] Vérifier les logs : arrêt brutal sans stack trace → Pattern #10 (ThreadPoolExecutor)
2. [ ] Ajouter try/except autour de chaque `future.result()` (Pattern #10)
3. [ ] Ajouter try/except autour de `evaluate_population()` dans la boucle principale (Pattern #10)
4. [ ] Vérifier NaN dans master_vec après evolve → Pattern #11 (NaN guard)
5. [ ] Ajouter `old_master_vec.clone()` avant l'update + détection NaN/Inf (Pattern #11)
6. [ ] Vérifier la mémoire GPU : `torch.cuda.empty_cache()` après chaque gen (Pattern #12)
7. [ ] Réduire `max_workers` de `len(devices)*3` à `len(devices)*2` (Pattern #12)

## Pattern #13 : Dilution du gradient ES avec données multi-symboles

**Symptôme** : Un seul agent ES entraîné sur 7 symboles (XAUUSD, EURUSD,
US30, BTCUSD...) ne converge pas. BUY et SELL restent quasi identiques
(±0.02) même après 30+ générations. Le winrate est bloqué à ~41%.

**Cause racine** : Chaque symbole a des dynamiques incompatibles :
- XAUUSD : volatil, valeurs refuges, corrélé à l'inflation
- EURUSD : range, macro, sensible aux taux d'intérêt
- BTCUSD : crypto, momentum-driven, décorrélé du forex
- US30 : indices, trend-following, gaps à l'ouverture

Un seul LSTM doit apprendre toutes ces dynamiques contradictoires.
Le gradient ES est la moyenne des gradients sur tous les symboles :
si XAUUSD dit BUY mais EURUSD dit SELL, le gradient net ≈ 0. Aucun
apprentissage de direction n'est possible.

**Preuve expérimentale** : Après 6 générations ES avec BUY/SELL dégelés
et 7 symboles, `buy_hold_gap = +7.01` mais `buy_sell_gap ≈ 0.00`.
Le réseau ne différencie pas BUY de SELL parce que le signal de
direction est noyé dans le mélange de symboles.

**Solution V6** : Architecture multi-agent spécialisé — un agent ES par
symbole. Chaque agent voit UN SEUL type de dynamique → gradient propre.

```
MultiAgentOrchestrator
 ├── SingleSymbolEnv(XAUUSD) → ESAgent(LSTM 2×128, 367k params)
 ├── SingleSymbolEnv(EURUSD) → ESAgent(LSTM 2×128, 367k params)
 ├── ... (un agent par symbole)
 └── MasterAgent (allocation de capital, Phase 2)
```

- Chaque agent esclave est entraîné indépendamment sur son symbole
- Le gradient ES n'est plus dilué → le réseau peut apprendre BUY vs SELL
- Les agents peuvent diverger : XAUUSD apprend à shorter, US30 à longer
- pop_size=8 suffit (données homogènes), eval_steps=500 (plus rapide)
- ~12s/génération pour 7 agents (vs ~100s pour 1 agent multi-symbole)

Implémentation de référence : `ftmo_agent/specialized_agents.py`.
Détails complets : `references/v6-multi-agent.md`.

**Piège** : Ne PAS réutiliser le MultiSymbolEnvV4 tel quel pour les
esclaves. Utiliser `SingleSymbolEnv` qui force le symbole après
construction (le `reset()` dans `__init__` change le symbole).

```python
class SingleSymbolEnv:
    def __init__(self, data_dict, symbol, ...):
        self.env = MultiSymbolEnvV4(data_dict, ...)
        # Forcer après construction (reset() dans __init__ l'a changé)
        self.env.current_symbol = symbol
        self.env.features, self.env.feature_names, self.env.df = data_dict[symbol]
        self.env.spec = SYMBOLS[symbol]
```

**Phase 2 (MasterAgent)** : Après pré-entraînement des esclaves, un agent
maître reçoit leurs signaux et apprend l'allocation de capital :
- Quels symboles trader (poids softmax sur N symboles + HOLD)
- Taille de position par symbole
- Gestion des corrélations (ex: ne pas longer US30 et shorter US500)

**Check-list multi-agent** :
1. [ ] Vérifier que chaque agent voit UN SEUL symbole (current_symbol fixe)
2. [ ] Vérifier que `n_features` est pris depuis l'environnement (pas les données brutes)
3. [ ] Logger `buy_sell_gap` par symbole : si >1.0, l'agent apprend la direction
4. [ ] Si buy_sell_gap ≈ 0 après 30+ gens sur UN symbole → features pas informatives
5. [ ] Phase 1 : entraînement indépendant (150 gens par agent)
6. [ ] Phase 2 : fine-tuning joint + MasterAgent (TODO)

### Résumé — 14 patterns documentés

Pour vérifier l'intégrité de l'agent ES après toute modification de
`es_agent.py`, exécuter le script de vérification :
`references/verify-es-policy.py` (7 tests : frozen_action_mask, forward,
evolve, NaN guard, empty_cache, evaluate_population, _validate).

## Pattern #14 : Bias BUY/SELL symétrique — pas de gradient de direction

**Symptôme** : Même avec BUY/SELL dégelés (Pattern #8), après 30+ générations
`buy_sell_gap ≈ 0.00` pour tous les symboles. Les politiques bruitées tradent
(t±=8/8) mais la validation déterministe du master fait 0 trades.

**Cause racine** : Avec `action_bias[BUY] = +3.0` et `action_bias[SELL] = +3.0`
(identiques), en mode stochastique BUY et SELL ont ~50% de chances chacun.
L'agent ouvre dans les deux sens aléatoirement. Le gradient ES ne peut pas
apprendre "BUY > SELL sur un marché haussier" car échantillonnage symétrique.

**Preuve expérimentale** :
- V5.1 (BUY/SELL dégelés, 7 symboles) : après 6 générations, buy_sell_gap ≈ 0
- V6 (agents spécialisés par symbole) : après 28 générations,
  buy_sell_gap ≈ 0 pour les 7 agents. Validation = 0 trades.

**Solution** : Injecter un signal de direction asymétrique dans le bias,
calculé à partir des features de marché. Le réseau n'apprend pas la
direction from scratch — il reçoit un "hint" et apprend le timing.

```python
class ESPolicy(nn.Module):
    def compute_directional_bias(self, features):
        trend = features[:, trend_indices].mean(dim=-1)
        direction = torch.tanh(trend * 10)  # ∈ [-1, +1]
        bias = self.action_bias.clone()
        bias[BUY] += direction * 2.0    # hausse → BUY favorisé
        bias[SELL] -= direction * 2.0   # hausse → SELL défavorisé
        return bias

    def forward(self, x, hidden=None):
        out, h = self.lstm(x, hidden)
        logits = self.head(out[:, -1, :])
        dir_bias = self.compute_directional_bias(out[:, -1, :])
        return logits * self.frozen_action_mask + dir_bias, h
```

**Résultat** : marché haussier → BUY=+5.0, SELL=+1.0. Marché baissier → inverse.
Le réseau peut TOUJOURS contrebalancer via les logits appris.

**Check-list** :
1. [ ] Si buy_sell_gap ≈ 0 après 10+ générations → Pattern #14
2. [ ] Ajouter un signal de direction dans le bias (tendance, momentum)
3. [ ] Vérifier que buy_sell_gap > 1.0 et suit la tendance du marché
4. [ ] Si le réseau contrebalance trop → réduire l'amplitude (×2 → ×1)

## Skills Liés

- `project-restructuring` : organisation du projet après prototypage RL
- `content-creation-guidelines` : conventions de commit en français